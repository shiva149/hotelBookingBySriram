package HotelBook;

import static org.junit.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
public static WebDriver driver;
	
	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver","D:\\selenium\\chromedriver.exe");
		 driver = new ChromeDriver();
	}

	@Given("^HotelBookingPage$")
	public void hotelbookingpage() throws Throwable {
		 driver.navigate().to("http://localhost:8081/HotelBooking/pages/hotelbooking.html");
	}

	@Given("^Verify Title$")
	public void verify_Title() throws Throwable {
		assertTrue(driver.getTitle().contains("Hotel Booking"));
	}

	@Given("^First Name Null$")
	public void first_Name() throws Throwable {
		driver.findElement(By.name("txtFN")).sendKeys("");
	}
	
	@
	
	@Given("^Last Name$")
	public void last_Name() throws Throwable {
		driver.findElement(By.name("txtLN")).sendKeys("Sri");
	}

	@Given("^Email$")
	public void email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^MobileNo$")
	public void mobileno() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^Address$")
	public void address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^City$")
	public void city() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^State$")
	public void state() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^No Of People Stay$")
	public void no_Of_People_Stay() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^CardholderName$")
	public void cardholdername() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^DebitCardNo$")
	public void debitcardno() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^CVV$")
	public void cvv() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^ExpiryMonth$")
	public void expirymonth() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^ExpiryYear$")
	public void expiryyear() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I complete action$")
	public void i_complete_action() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Book Hotel$")
	public void book_Hotel() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

}
